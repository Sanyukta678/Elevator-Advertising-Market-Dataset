# Elevator Advertising Market — Dataset

This dataset contains structured metadata and summaries derived from the public landing page of the Elevator Advertising Market report (SE3566) by Next Move Strategy Consulting.

Includes:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- table_of_contents.md
- license.txt

This dataset contains *only publicly available* information. No paid report content is included.
